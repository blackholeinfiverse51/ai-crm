import pandas as pd
from datetime import datetime
from human_review import review_system

try:
    from notification_service import send_info_alert, send_success_alert, send_warning_alert, send_critical_alert
    NOTIFICATIONS_ENABLED = True
except ImportError:
    NOTIFICATIONS_ENABLED = False
    def send_info_alert(*args, **kwargs): pass
    def send_success_alert(*args, **kwargs): pass
    def send_warning_alert(*args, **kwargs): pass
    def send_critical_alert(*args, **kwargs): pass

# === Config ===
RETURNS_FILE = "data/returns.xlsx"
RESTOCK_FILE = "data/restock_requests.xlsx"
LOG_FILE = "data/logs.csv"
THRESHOLD = 5

# === Step 1: Sense ===
def sense():
    print("🔍 Reading returns data...")
    return pd.read_excel(RETURNS_FILE)

# === Step 2: Plan ===
def plan(df):
    print("🧠 Planning restock actions...")
    restocks = []
    for index, row in df.iterrows():
        if row["ReturnQuantity"] > THRESHOLD:
            restocks.append({
                "ProductID": row["ProductID"],
                "RestockQuantity": row["ReturnQuantity"]
            })
    return restocks

# === Step 3: Act ===
def act(restocks):
    if restocks:
        # Send alert about restock processing
        send_info_alert("Restock Processing Started", 
                       f"Processing {len(restocks)} restock requests",
                       {"total_requests": len(restocks), "timestamp": datetime.now().isoformat()})
        
        # Check each restock for human review requirement
        approved_restocks = []
        review_items = []

        for restock in restocks:
            action_data = {
                "product_id": restock["ProductID"],
                "quantity": restock["RestockQuantity"]
            }

            if review_system.requires_human_review("restock", action_data):
                # Submit for human review
                decision = f"Restock {restock['ProductID']} with quantity {restock['RestockQuantity']}"
                review_id = review_system.submit_for_review("restock", action_data, decision)
                print(f"⏳ Restock for {restock['ProductID']} pending human review (ID: {review_id})")
                review_items.append(restock)
                
                # Send warning alert for items requiring review
                send_warning_alert("Human Review Required", 
                                 f"Restock for {restock['ProductID']} requires human review",
                                 {"product_id": restock["ProductID"], 
                                  "quantity": restock["RestockQuantity"],
                                  "review_id": review_id})
            else:
                # Auto-approve high confidence decisions
                approved_restocks.append(restock)
                print(f"✅ Auto-approved restock for {restock['ProductID']}")

        # Execute approved restocks
        if approved_restocks:
            print("📝 Writing approved restock requests...")
            df = pd.DataFrame(approved_restocks)
            df.to_excel(RESTOCK_FILE, index=False)
            log_actions(approved_restocks)
            
            # Send success alert for approved restocks
            send_success_alert("Restocks Approved", 
                             f"Successfully processed {len(approved_restocks)} automatic restocks",
                             {"approved_count": len(approved_restocks),
                              "products": [r["ProductID"] for r in approved_restocks]})

        if len(approved_restocks) < len(restocks):
            print(f"ℹ️ {len(restocks) - len(approved_restocks)} restock(s) pending human review")
    else:
        print("ℹ️ No restock needed.")
        send_info_alert("Restock Check Complete", "No restocks needed at this time")

# === Log actions ===
def log_actions(restocks):
    timestamp = datetime.now().isoformat()
    logs = []
    for item in restocks:
        logs.append({
            "Time": timestamp,
            "Action": "RestockRequest",
            "ProductID": item["ProductID"],
            "Quantity": item["RestockQuantity"]
        })
    df = pd.DataFrame(logs)
    df.to_csv(LOG_FILE, mode='a', index=False, header=not pd.io.common.file_exists(LOG_FILE))
    print("📜 Actions logged.")

# === Main Agent Flow ===
def run_agent():
    try:
        send_info_alert("Agent Cycle Started", "Restock agent beginning processing cycle")
        returns = sense()
        plan_result = plan(returns)
        act(plan_result)
        send_success_alert("Agent Cycle Complete", "Restock agent completed processing cycle successfully")
        return True
    except Exception as e:
        error_msg = f"Agent error: {str(e)}"
        print(f"⚠️  {error_msg}")
        
        # Send critical alert for agent errors
        send_critical_alert("Agent Error", error_msg, 
                           {"error_type": type(e).__name__,
                            "error_details": str(e),
                            "timestamp": datetime.now().isoformat()})
        
        # Log error but don't crash
        import datetime
        error_log = [{
            'timestamp': datetime.datetime.now().isoformat(),
            'action': 'error',
            'ProductID': 'N/A',
            'quantity': 0,
            'confidence': 0.0,
            'human_review': True,
            'details': f"Error: {str(e)}"
        }]
        df = pd.DataFrame(error_log)
        df.to_csv(LOG_FILE, mode='a', index=False, header=not pd.io.common.file_exists(LOG_FILE))
        return False

# === Run ===
if __name__ == "__main__":
    run_agent()
